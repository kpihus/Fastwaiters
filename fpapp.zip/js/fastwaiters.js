/**
 * Created by Kristjan on 9.10.2014.
 */
$(document).ready(function(){
   /** Pinpad and auth **/

   nupp = document.getElementsByClassName("numbtn");
    pinfield = document.getElementById("pinfield");
    var flag = false;
    $(nupp).bind('touchstart click', function(){
        if (!flag) {
            flag = true;
            setTimeout(function(){ flag = false; }, 100);
            $('.numbtn').css('background-color','rgba(255,255,255,0.9)');
            $(this).css('background-color','rgba(230,77,37,0.7)');
            var nr=$(this).data('nr');
            var old=$(pinfield).val();
            $(pinfield).val(old+nr);
        }
        return false
    });
    $(nupp).bind('touchend',function(){
        $(this).css('background-color','rgba(255,255,255,0.9)');
    });



    $('.clrbtn').click(function(){
        var nr=$(pinfield).val();
        pinval = nr.substr(0,nr.length-1)
        $(pinfield).val(pinval);
    });
    $('.entbtn').click(function(){
        var server = $('#server').val();
        var clientcode = $('#clientcode').val();
        var pin = $('#pinfield').val();
        $.ajax({
            url: server,
            type: "POST",
            data: {
                pincode: pin,
                client: clientcode
            },
            success: function(data){
                console.log(data);
                if(data=="fail"){
                    alert('failed');
                }else if(data=="success"){
                    alert('success');
                }
            }
        })

    })





});